--\i conf/delete.sql
\i conf/create.sql
\i conf/views.sql
\i conf/insert.sql
\i conf/triggers.sql

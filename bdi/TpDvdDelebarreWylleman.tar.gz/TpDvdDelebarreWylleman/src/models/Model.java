package models;

public interface Model {
	
}